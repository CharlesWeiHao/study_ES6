'use strict';

let cook = 'cookie';
let drink = 'milk';

function dinner(cook, drink) {
  return `cook : ${cook} - drink : ${drink}`;
}

// 导出定义的变量
// dinner as supper : 表示更改导出的函数名称
export {cook, drink , dinner as supper};


// 默认导出的方式一
export default function defaultFun1 (cook, drink) {
  return `cook : ${cook} - drink : ${drink}`;
}

// 默认导出的方式二
function defaultFun2 (cook, drink) {
  return `cook : ${cook} - drink : ${drink}`;
}
export {defaultFun2 as default};
