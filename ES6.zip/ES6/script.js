// 使用严格模式
'use strict';


// 1、块的作用域
// if (true) {
//   // var 定义的变量作用域是全局
//   // var 变量可以多次声明
//   var fruit = 'apple';
//   // let 定义的变量作用域是在这个函数内部
//   // let 变量只能声明一次
//   let fruit = 'bananr';
// }
// console.log(fruit);

// 2、定义变量可以使用大括号{}
// {
//   // let 定义的变量，在定义的作用域外部不可以访问
//   let fruit = 'apple';
//   var banana = 'banana';
// }
//
// // console.log(fruit);
// console.log(banana);

// 3、const 恒量 限制重复定义或者分配新的值，不限制定义的内部值
// const fruit = [];
// fruit.push('banana');
// fruit.push('lemon');
// console.log(fruit);


// 4、结构数组
// function breakfast () {
//   return ['🍰','🍵','🍎'];
// }
//
// // var tmp = breakfast (),
// //   dessert = tmp[0], drink = tmp[1], fruit = tmp[2];
// // 定义结构数组
// let [dessert, drink, fruit] = breakfast();
//
// console.log(dessert, drink, fruit);

// 5、解构对象
// function breakfast () {
//   return {dessert : '🍰', drink : '🍺', fruit : '🍎'};
// }
// // 定义一个对象，给定义的对象赋值
// let {dessert : dessert , drink: drink , fruit : fruit} = breakfast();
//
// console.log(dessert, drink, fruit);

// 6、模板字符串
// let fruit = 'apple',
//     drink = 'milk';
// // 默认写法
// // let breakfast = 'breakfast：' + fruit + ' and ' + drink + '.';
// // 模板字符串写法
// let breakfast = `breakfast: ${fruit} And ${drink}`;
//
// console.log(breakfast);

// 7、带标签的模板字符串
// let fruit = 'apple',
//     drink = 'milk';
//
// let breakfast = kitchen `breakfast : ${fruit} and ${drink} .`
//
// // 定义带标签的字符串函数
// function kitchen(strings, ...values) {
//
//   // console.log(strings);
//   // console.log(values);
//
//   // 循环遍历标签字符串
//   let result = '';
//   for (var i = 0; i < values.length; i++) {
//     result += strings[i];
//     result += values[i];
//    }
//    result += strings[strings.length - 1];
//
//    return result;
//
// }
// console.log(breakfast);


// 8、判断字符串里面是否包含其他字符串
// let fruit = 'apple',
//     drink = 'milk';
//
// // 模板字符串写法
// let breakfast = `breakfast: ${fruit} And ${drink}`;
//
// console.log(
//   // startsWith 已什么开头
//   breakfast.startsWith('a'),
//   // endsWith 已什么结尾
//   breakfast.endsWith('k'),
//   // includes 是否包含某个字符串
//   breakfast.includes('k')
// );

// 9、默认参数
// function breakfast(dessert = 'apple', drink = 'beer') {
//   return `${dessert} + ${drink}`;
// }
//
// console.log(
//   // 打印默认定义的值
//   breakfast(),
//   // 打印调用函数从新设置的值
//   breakfast('banana', 'milk')
// );

// 10、展开操作符（...）spread
// let fruits = ['apple', 'banana'],
//     // foods 数组包含 fruits数据
//     foods = ['cookie', ...fruits];
//
// console.log(fruits);
// // 打印展开的数组信息
// console.log(...fruits);
// // 打印foods数组信息
// console.log(foods);

// 11、剩余操作符 (...) rest
// ...foods 表示剩余的参数都会放到foods数组中，
// function breakfast(dessert, drink, ...foods) {
//   console.log(dessert, drink, ...foods);
// }
//
// breakfast('cookie', 'beer', 'apple', 'banana');

// 12、解构参数 destructured parameters
// 函数参数可以包含对象
// function breakfast(dessert, drink, {location, restaurant}) {
//   console.log(dessert, drink, location, restaurant);
// }
// // 调用并赋值对象。
// breakfast('cookie', 'milk', {location : 'beijing', restaurant : 'beijing hotle'});

//13、 函数名称 name
// let letBreakfast = function breakfast () {
//
// }
// console.log(
//   letBreakfast.name
// );
// let letBreakfast = function superBreakfast (argument) {
// }
// console.log(
//   letBreakfast.name
// );

//14、 箭头函数 arrow Funcation
/**
  箭头函数的写法
  breakfast ： 声明了一个变量来管理函数
  第一个 dessert ：函数的参数
  第二个 dessert ：函数的返回值
*/
// let breakfast = dessert => dessert;
// 翻译为普通函数的定义
// var breakfast = function breakfast(dessert) {
//   return dessert;
// }

// 也可以带多个参数
// let breakfast = (dessert, drink) => dessert + drink;

// let breakfast = (dessert, drink) => {
    // return dessert + drink;
// };

// // 翻译为普通函数的定义
// var breakfast = function breakfast(dessert, drink) {
//   return dessert + drink;
// }

//15、对象表达式
// let dessert = 'cookie', drink = 'milk';
//
// let foods = {
//   // 定义属性
//   dessert,
//   drink,
//   // 定义函数
//   breakfast(){}
// }
// console.log(foods);

//15、对象表达式
// let foods = {};
// // 给对象属性赋值方式
// foods.dessert = 'cookie';
// // 给对象的属性（中间带括号）赋值方式
// foods['hot drink'] = 'green tea'
// console.log(foods);

// 16、对比两个值是否相等 （== 、 ===）
// '==' 判断两个值是否相等
// '===' 判断两个值是否绝对相等
// 'Object.is' 判断两个对象是否相等

// 17、把一个对象的值复制给另一个对象 object.assign()
// let breakfast = {};
// // assign包含两个参数，第一个参数表示：复制到的那个对象，第二个参数表示：复制的对象
// Object.assign(
//   breakfast,
//   {drink:'beer'}
// );
// console.log(breakfast);

// 18、设置对象的prototype(原型) 【 Object.setPrototypeOf() 】
// let breakfast = {
//   getDrink () {
//     return 'beer';
//   }
// };
//
// let dinner = {
//   getDrink () {
//     return 'green tea';
//   }
// }
// // 创建一个基于breakfast对象的对象
// let sunday = Object.create(breakfast);
// // 打印sunday对象的getDrink方法
// console.log(sunday.getDrink());
// // 判断sunday对象的prototype是否等于breakfast对象的prototype
// console.log(Object.getPrototypeOf(sunday) === breakfast);
// // 从新设置一个sunday对象的prototype
// // 第一个参数是被设置prototype的对象，
// // 第二个参数是需要设置成为的那个对象
// Object.setPrototypeOf(sunday, dinner);
// console.log(sunday.getDrink());
// console.log(Object.getPrototypeOf(sunday) === dinner);

// 19、设置对象的 __proto__ ,这是上那种类型的简化版
// let breakfast = {
//   getDrink () {
//     return 'beer';
//   }
// };
//
// let dinner = {
//   getDrink () {
//     return 'green tea';
//   }
// }
// // 不是create方法，而使用这种方式
// let sunday = {
//     __proto__ : breakfast
// };
//
// console.log(sunday.getDrink());
// console.log(Object.getPrototypeOf(sunday) === breakfast);
// // 设置新的对象
// sunday.__proto__ = dinner;
// console.log(sunday.getDrink());
// console.log(Object.getPrototypeOf(sunday) === dinner);

// 20、super
// let breakfast = {
//   getDrink () {
//     return 'beer';
//   }
// };
//
// let dinner = {
//   getDrink () {
//     return 'green tea';
//   }
// }
// // 定义一个对象，并重新执行一下父类的方法
// let sunday = {
//     __proto__ : breakfast,
//     // 在sunday对象里，调用父类的drink方法，并返回新的值
//     getDrink () {
//       return super.getDrink() + ' milk ' + ' water';
//     }
// };
// console.log(sunday.getDrink());

// 21、迭代器 iterators next函数有两个参数：{value : xx, done : ture/ false}
// 手动创建迭代器
// 定义一个厨师的函数，参数：foods
// function chef(foods) {
//   let i = 0;
//   // 返回一个对象
//   return {
//     // 调用next（）函数
//     next () {
//       // 判断done的值
//       let done = (i >= foods.length);
//       // 获取value的值
//       let value = !done ? foods[i++] : undefined;
//       // 返回一个对象包含 value 和 done值
//       return {
//         value : value,
//         done : done
//       }
//     }
//   }
// }
// // 使用函数
// let zhangsan = chef(['apple', 'banana']);
// // 打印 apple 的值
// console.log(zhangsan.next());
// // 打印 banana 的值
// console.log(zhangsan.next());
// // 打印 undefind 的值
// console.log(zhangsan.next());

// 22、生成器 Generators
// 定义函数表达式的生成器
// let chef = function * (foods) {
//   for (var i = 0; i < foods.length; i++) {
//     // 使用 yield 关键字来生成
//     yield foods[i];
//   }
// }
// let zhangsan = chef (['apple', 'banana']);
// // 打印 apple 的值
// console.log(zhangsan.next());
// // 打印 banana 的值
// console.log(zhangsan.next());
// // 打印 undefind 的值
// console.log(zhangsan.next());

// 23、Class （new class）
// class Chef {
//   // 方法构造器
//   constructor (food) {
//     // 对象的属性
//     this.food = food;
//   }
//   // 自定义cook方法，打印对象food
//   cook () {
//     console.log(this.food);
//   }
// }
//
// let zhangsan = new Chef('apple');
// zhangsan.cook();

// 24、Class （get和set）
// class Chef {
//
//   // 方法构造器
//   constructor (food) {
//     // 对象的属性
//     this.food = food,
//     this.dish = [];
//   }
//
//   // 设置get方法
//   get newGetMenu () {
//     return this.dish;
//   }
//   // 设置set方法
//   set newSetMenu (dish) {
//     this.dish.push(dish);
//   }
//
//   // 自定义cook方法，打印对象food
//   cook () {
//     console.log(this.food);
//   }
// }

// let zhangsan = new Chef('foods');
// zhangsan.cook();
// console.log(zhangsan.newSetMenu = 'cookie');
// console.log(zhangsan.newSetMenu = 'beer');
// console.log(zhangsan.newGetMenu);

 // 25、Class static
// class Chef {
//   constructor () {
//   }
//   // 声明静态方法
//   static cook (food) {
//     console.log(food);
//   }
// }
// // 直接用类名来调用静态方法
// Chef.cook('apple + banana');

// 26、Class 继承
// class Person {
//   constructor(name, age) {
//     this.name = name;
//     this.age = age;
//   }
//
//   intro () {
//     return `name : ${this.name} , age :${this.age}`;
//   }
// }
//
// // 创建一个类，继承与Person类
// class Chef extends Person {
//   constructor(name, age) {
//     // 调用父类的方法
//     super(name, age);
//   }
// }
//
// let wangwu = new Chef('wangwu', '20');
// console.log(wangwu.intro());

// 27、Set 集合
// let dessert = new Set('🍨🍦🍓🍪');
// console.log(dessert);
// // 个数
// console.log(dessert.size);
// // 新增
// dessert.add('❄️');
// dessert.add('🌧');
// console.log(dessert);
// // 删除
// dessert.delete('🍦');
// console.log(dessert);
// // 包含
// console.log(dessert.has('🍓'));
// // 遍历
// dessert.forEach(dessert => {
//   console.log(dessert);
// });
// // 清除所有
// dessert.clear();
// console.log(dessert);

// 28、Map 字典
// let food = new Map ();
// let fruit = {}, dessert = function () {}, cook = 'cookie';
//
// // 添加
// food.set(fruit, 'apple');
// food.set(dessert, 'funcation');
// food.set(cook, 'new cookie');
// console.log(food);
//
// // 个数
// console.log(food.size);
//
// // 删除
// food.delete(dessert);
// console.log(food);
//
// // 包含
// console.log(food.has(cook));
//
// // 获取某个值
// console.log(food.get(cook));
// console.log(food.get(fruit));
//
// // 遍历
// food.forEach(food => {
//   console.log(food);
// })
//
// // 清除所有
// food.clear();
// console.log(food);

// 29、Module 模块
// 导入的类定义的属性
// import {cook, drink} from './modules/chef';
// console.log(cook, drink);

// 导入的类
// import * as chef from './modules/chef';
// console.log(chef.cook, chef.drink);

// 导入的类定义的属性 和 方法
// supper as dinner : 表示更改导入的函数名称
// import {cook, drink, supper as dinner} from './modules/chef';
// dinner(cook, drink);

// 导入默认的函数
// import defaultFun1 from './modules/chef';
// defaultFun1('cookies', 'bananas');
//
// import defaultFun2 from './modules/chef';
// defaultFun2('milk', 'apple');
